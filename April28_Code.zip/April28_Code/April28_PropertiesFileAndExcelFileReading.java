package com.selenium.automation;

import java.io.IOException;

public class April28_PropertiesFileAndExcelFileReading extends BaseClass{
	
	public static void main(String[] args) throws Exception {
		testisDisplayed();
	}
	
	public static void readDataFromPropertiesFile() throws IOException
	{
		String url = getDataFromPropertiesFile("url");		
		launchActiTimeApplication(url);	
		
	}
	
	public static void testisDisplayed() throws Exception
	{
		String url = getDataFromPropertiesFile("url");		
		launchActiTimeApplication(url);	
		boolean result = loginToActiTimeApplication();
		
		System.out.println(result);
		
	}

}
