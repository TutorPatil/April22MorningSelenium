package com.selenium.automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {
	
	public static String url = "";
	static WebDriver driver = null;
	
	
	public static String getDataFromPropertiesFile(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/configdata.properties");
		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of Properties class
		Properties prop = new Properties();
		
		// Loading the data from the properties file
		prop.load(fio);
		
		// Fetch the value of a porperty using its key
		value = prop.getProperty(key);
		
		
		return value;
	}


	public static void launchActiTimeApplication(String url) throws IOException
	{
		// To clean up chrome driver use the below command
		//taskkill /im chromedriver.exe /f
		String browser = getDataFromPropertiesFile("browser");
		System.out.println("The Test cases will be run using the browser =="+browser);
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./Utilities/chromedriver.exe");		
			driver = new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./Utilities/geckodriver.exe");		
			driver = new FirefoxDriver();
		}
		// implicit wait is applied only once and is applicable for the life span of the driver.
		String time = getDataFromPropertiesFile("timeout");
		int timeout = Integer.parseInt(time);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));	
		
		driver.get(url);
		driver.manage().window().maximize();
		
	}
	
	
	public static boolean loginToActiTimeApplication()
	{
		boolean logoutDisaplyed = false;
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");		
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
				
		try {
			logoutDisaplyed = driver.findElement(By.xpath("//a[@id='logoutLink']")).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return logoutDisaplyed;
		
	}
	

}
