package com.actitime.tests;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v100.page.Page.CaptureScreenshotFormat;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.utils.CommonUtils;

public class Login extends BaseClass{
	
	//@Test(priority = 1)
	//@Test
	
	@Test(groups = { "smoke", "login","login_001" })
	public static void login_001() throws Exception
	{
		boolean result = false;			
	   		
		writeLogs("Trying to login to the actitime application by calling login method..");		
		result = CommonUtils.loginToActiTimeApplication();		
		
		// Checking the result to be equal to true
		Assert.assertTrue(result, "Could not login to ActiTime application..");
			
			
		
	}
	//@Test(enabled = false) // To skip any test case from execution.
	//@Test(priority = 2) // To give the priority / Order of execution in the sequence...
	//@Test(dependsOnMethods = { "login_001" })
	//@Test(dependsOnMethods = { "login_001" }, priority = 2, enabled = true)
	
	@Test(groups = { "regression", "login","login_002" })
	public static void login_002() throws Exception
	{
		boolean result = false;			
		
		writeLogs("Trying to login to the actitime application by calling login method..");		
		result = CommonUtils.loginToActiTimeApplication("admin"	,"manager123");
		
		Assert.assertFalse(result,"Invald login failed");
		
				
			
		
		
	}
	
	
	
	
	
}
