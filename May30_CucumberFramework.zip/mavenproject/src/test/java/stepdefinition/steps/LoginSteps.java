package stepdefinition.steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	
	WebDriver driver ;
	
@Given("User is on login page")
public void user_is_on_login_page() {

	System.setProperty("webdriver.chrome.driver", "./src/test/Utilities/chromedriver.exe");		
	driver = new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	driver.get("https://demo.actitime.com");
	driver.manage().window().maximize();
}

@When("User enters {string} as valid username and {string} as valid password")
public void user_enters_as_valid_username_and_as_valid_password(String userN, String string2) {
    driver.findElement(By.id("username")).sendKeys("admin");
    driver.findElement(By.name("pwd")).sendKeys("manager");   
    
}

@When("Clicks on Login Page")
public void clicks_on_login_page() {
	driver.findElement(By.id("loginButton")).click();
}

@Then("User is naavigated to the home page")
public void user_is_naavigated_to_the_home_page() {
	boolean isDislayed = driver.findElement(By.id("logoutLink")).isDisplayed();
	Assert.assertTrue(isDislayed," User could not login  to Actitime...");
	driver.close();
	
}

}
