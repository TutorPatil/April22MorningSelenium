package com.actitime.pagetests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.actitime.base.BaseClass;
import com.actitime.pages.HomePage;
import com.actitime.pages.LoginPage;

public class LoginTests extends BaseClass{
	
	@Test
	public static void login_001()
	{
		// Creating the object of Login  Page to access Login page members
		LoginPage login = new LoginPage(driver);
		
		login.setUserName("admin");
		login.setPassword("manager123");
		login.clickLoginBtn();
		
		
		boolean result = login.verifyErrorMessage();
		Assert.assertTrue(result,"Error message is not displayed!!");
		
		
		
	}
	@Test
	public static void login_002()
	{
		// Creating the object of Login  Page to access Login page members
		LoginPage login = new LoginPage(driver);
		login.setUserName("admin");
		login.setPassword("manager");
		login.clickLoginBtn();
		
		// Creating the object of Home Page to access home page members
		HomePage home = new HomePage(driver);
		boolean result = home.verifyLogoutLinkDisplayed();
		Assert.assertTrue(result,"Logout Link not displayed!!");
		
		
		
	}
	
	
	

}
