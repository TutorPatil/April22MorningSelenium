package com.actitime.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.actitime.base.BaseClass;

public class LoginPage {
	
	
	private WebDriver driver = null;
	
	// writing constructor for the Login Page to initialize all the elemnets using Page Factory
	
	public LoginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	
	
	// WebElement username = driver.findElement(By.xpath("//input[@id='username']");
	@FindBy(xpath = "//input[@id='username']")
	private WebElement userName;
	
	@FindBy(name = "pwd")
	private WebElement password;
	
	@FindBy(id = "loginButton")
	private WebElement loginButton;
	
	@FindBy(xpath = "//span[contains(text(),'Username or Password is invalid')]")
	private WebElement errorMsg;
	
	
	public void setUserName(String userNameData)
	{
		userName.sendKeys(userNameData);
	}
	
	
	public void setPassword(String passwordData)
	{
		password.sendKeys(passwordData);
	}
	
	public void clickLoginBtn()
	{
		loginButton.click();
	}
	
	public boolean verifyErrorMessage()
	{
		boolean errorDisplayed = false;
		
		try {
			errorDisplayed = errorMsg.isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	return errorDisplayed;
		
	}
	
	

}
