package com.actitime.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	

	private WebDriver driver = null;
	
	// writing constructor for the Login Page to initialize all the elemnets using Page Factory
	
	public HomePage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "logoutLink")
	private WebElement logoutLink;
	
	
	public boolean verifyLogoutLinkDisplayed()
	{
		boolean logoutLinkDisplay = false;
		
		try {
			logoutLinkDisplay = logoutLink.isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	return logoutLinkDisplay;
	}
	

}
