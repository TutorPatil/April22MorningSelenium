package com.actitime.tests;

import com.actitime.base.BaseClass;

public class TestRunner extends BaseClass{

	public static void main(String[] args) throws Exception {
		
		Login.login_001();
		Login.login_002();
				

	}

}

