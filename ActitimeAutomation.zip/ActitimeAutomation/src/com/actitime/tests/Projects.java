package com.actitime.tests;

import com.actitime.base.BaseClass;

public class Projects extends BaseClass{

}
