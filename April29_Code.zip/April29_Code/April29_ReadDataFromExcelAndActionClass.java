package com.selenium.automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class April29_ReadDataFromExcelAndActionClass extends BaseClass{

	public static void main(String[] args) throws IOException {
		
		launchActiTimeApplication(getDataFromPropertiesFile("url"));
		//boolean isLoggedIn = loginToActiTimeApplication();
		//System.out.println(isLoggedIn);
		
		actiTimeLoginWithDifferntData();
		driver.quit();
	}
	
	
}
