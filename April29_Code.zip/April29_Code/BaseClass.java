package com.selenium.automation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {
	
	public static String url = "";
	static WebDriver driver = null;
	
	
	public static String getDataFromPropertiesFile(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/configdata.properties");
		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of Properties class
		Properties prop = new Properties();
		
		// Loading the data from the properties file
		prop.load(fio);
		
		// Fetch the value of a porperty using its key
		value = prop.getProperty(key);
		
		
		return value;
	}


	public static void launchActiTimeApplication(String url) throws IOException
	{
		// To clean up chrome driver use the below command
		//taskkill /im chromedriver.exe /f
		String browser = getDataFromPropertiesFile("browser");
		System.out.println("The Test cases will be run using the browser =="+browser);
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./Utilities/chromedriver.exe");		
			driver = new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./Utilities/geckodriver.exe");		
			driver = new FirefoxDriver();
		}
		// implicit wait is applied only once and is applicable for the life span of the driver.
		String time = getDataFromPropertiesFile("timeout");
		int timeout = Integer.parseInt(time);
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));	
		
		driver.get(url);
		driver.manage().window().maximize();
		
	}
	
	
	public static boolean loginToActiTimeApplication() throws IOException
	{
		boolean logoutDisaplyed = false;
		
		
		
		driver.findElement(By.xpath(getLocatorData("Login", "UserName_EditBox"))).sendKeys(getTestData("Login", "UserName_EditBox"));
		driver.findElement(By.xpath(getLocatorData("Login", "Password_EditBox"))).sendKeys(getTestData("Login", "Password_EditBox"));		
		driver.findElement(By.xpath(getLocatorData("Login", "Login_Button"))).click();
		
				
		try {
			logoutDisaplyed = driver.findElement(By.xpath(getLocatorData("Home", "Logout_Link"))).isDisplayed();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return logoutDisaplyed;
		
	}
	
	
	public static void actiTimeLoginWithDifferntData() throws IOException
	{
		boolean logoutDisaplyed = false;
		
		String username = getTestData("Login", "UserName_EditBox");
		String password = getTestData("Login", "Password_EditBox");
		
		String[] userNameData = username.split("#");
		String[] passwordData = password.split("#");
		
		for( int x=0; x<userNameData.length;x++)
		{
			driver.findElement(By.xpath(getLocatorData("Login", "UserName_EditBox"))).sendKeys(userNameData[x]);
			driver.findElement(By.xpath(getLocatorData("Login", "Password_EditBox"))).sendKeys(passwordData[x]);		
			driver.findElement(By.xpath(getLocatorData("Login", "Login_Button"))).click();
			
			WebElement logoutLink = driver.findElement(By.id("logoutLink"));
			JavascriptExecutor jsEx = (JavascriptExecutor)driver;
			jsEx.executeScript("arguments[0].click()", logoutLink);			
			
			
		}
		
		
		
	}
	
	
	public static String getLocatorData(String pageName, String elementName) throws IOException
	{
		String locator ="";
		
		File f = new File("./data/locatordata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of the Work Book	
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		// Creating the object of WOrk Sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		// To get the number of used rows
		int rows = ws.getLastRowNum();		
		//System.out.println(rows);
		
		for(int x=1; x<=rows;x++)
		{
			
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				locator = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}		
		}		
		wb.close();	
		return locator;
	}
	
	
	
	public static String getTestData(String pageName, String elementName) throws IOException
	{
		String data ="";
		
		File f = new File("./data/testdata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the object of the Work Book	
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		// Creating the object of WOrk Sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		// To get the number of used rows
		int rows = ws.getLastRowNum();		
		//System.out.println(rows);
		
		for(int x=1; x<=rows;x++)
		{
			
			String page = ws.getRow(x).getCell(0).getStringCellValue();
			String element = ws.getRow(x).getCell(1).getStringCellValue();
			
			if((pageName.equalsIgnoreCase(page)) && (elementName.equalsIgnoreCase(element)))
			{
				data = ws.getRow(x).getCell(2).getStringCellValue();
				break;
			}		
		}		
		wb.close();	
		return data;
	}


}
